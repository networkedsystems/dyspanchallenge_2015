#!/bin/sh

export LD_LIBRARY_PATH=lib_x64/

./example
